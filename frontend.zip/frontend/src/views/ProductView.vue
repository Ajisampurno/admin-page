<template>
    <ProductTable/>
</template>