<template>
    <CategorieTable/>
</template>
<script>
export default {
  data() {
  }
}
</script>