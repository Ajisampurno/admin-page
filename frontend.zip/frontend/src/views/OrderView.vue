<template>
  <OrderTable/>
</template>
<script>
export default {
  data() {
  }
}
</script>